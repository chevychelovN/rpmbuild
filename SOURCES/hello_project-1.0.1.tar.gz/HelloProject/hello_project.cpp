#include <iostream>

int main()
{
    std::cout << "Test task in RAIDIX!" << std::endl;
    return 0;
}
